"""
Comprehensive test script for the post recommendation system
Tests all new routes and validates the ML pipeline
"""

import requests
import json
import time
from datetime import datetime, timedelta
import random
import psycopg2
from psycopg2.extras import RealDictCursor

# Configuration
BASE_URL = "http://localhost:5000"
DB_CONFIG = {
    'host': '167.86.115.58',
    'port': 5432,
    'dbname': 'prospects_dev',
    'user': 'devuser',
    'password': 'testdev123'
}

# Test data
TEST_USERS = [
    "01HXA7B2C3D4E5F6G7H8J9K0M1",
    "01HXA7B2C3D4E5F6G7H8J9K0M2",
    "01HXA7B2C3D4E5F6G7H8J9K0M3"
]

TEST_POSTS = []


class Colors:
    """ANSI color codes for terminal output"""
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


def print_test(message):
    """Print test name"""
    print(f"\n{Colors.BOLD}{Colors.OKBLUE}🧪 TEST: {message}{Colors.ENDC}")


def print_success(message):
    """Print success message"""
    print(f"{Colors.OKGREEN}✓ {message}{Colors.ENDC}")


def print_error(message):
    """Print error message"""
    print(f"{Colors.FAIL}✗ {message}{Colors.ENDC}")


def print_warning(message):
    """Print warning message"""
    print(f"{Colors.WARNING}⚠ {message}{Colors.ENDC}")


def print_info(message):
    """Print info message"""
    print(f"{Colors.OKCYAN}ℹ {message}{Colors.ENDC}")


def setup_test_data():
    """Create test posts and players in the database"""
    print_test("Setting up test data")

    try:
        conn = psycopg2.connect(**DB_CONFIG)
        cur = conn.cursor(cursor_factory=RealDictCursor)

        # Check if posts table exists
        cur.execute("""
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_name = 'posts'
            );
        """)

        if not cur.fetchone()['exists']:
            print_error("Posts table doesn't exist. Run posts_schema.sql first!")
            return False

        # Get some active players for test posts
        cur.execute("""
            SELECT id FROM players 
            WHERE status = 'active' AND deleted_at IS NULL 
            LIMIT 5;
        """)

        players = cur.fetchall()

        if not players:
            print_error("No active players found. Need players to create posts.")
            return False

        print_info(f"Found {len(players)} active players")

        # Create test posts if they don't exist
        global TEST_POSTS
        TEST_POSTS = []

        for i, player in enumerate(players):
            post_id = f"01HXA7B2C3D4E5F6G7H8J9K0P{i:02d}"

            # Check if post already exists
            cur.execute("SELECT id FROM posts WHERE id = %s", (post_id,))

            if not cur.fetchone():
                content_options = [
                    "Great training session today! 💪",
                    "Just finished an amazing match! ⚽",
                    "Working on my skills 🏃‍♂️",
                    "Team practice was intense today 🔥",
                    "New personal best on sprint time! 🎯"
                ]

                hashtag_options = [
                    ['training', 'fitness'],
                    ['match', 'victory'],
                    ['skills', 'improvement'],
                    ['teamwork', 'practice'],
                    ['achievement', 'milestone']
                ]

                cur.execute("""
                    INSERT INTO posts (id, player_id, content, hashtags, created_at)
                    VALUES (%s, %s, %s, %s, %s)
                    ON CONFLICT (id) DO NOTHING;
                """, (
                    post_id,
                    player['id'],
                    content_options[i % len(content_options)],
                    hashtag_options[i % len(hashtag_options)],
                    datetime.now() - timedelta(hours=random.randint(1, 48))
                ))

                print_success(f"Created test post: {post_id}")
            else:
                print_info(f"Post {post_id} already exists")

            TEST_POSTS.append(post_id)

        conn.commit()
        cur.close()
        conn.close()

        print_success(f"Test data setup complete. {len(TEST_POSTS)} posts available.")
        return True

    except Exception as e:
        print_error(f"Failed to setup test data: {str(e)}")
        return False


def test_health_check():
    """Test the health check endpoint"""
    print_test("Health Check")

    try:
        response = requests.get(f"{BASE_URL}/health")

        if response.status_code == 200:
            data = response.json()
            print_success(f"API is healthy: {data['status']}")
            print_info(f"Services: {json.dumps(data['services'], indent=2)}")
            return True
        else:
            print_error(f"Health check failed: {response.status_code}")
            return False
    except Exception as e:
        print_error(f"Health check error: {str(e)}")
        return False


def test_log_post_interaction():
    """Test logging post interactions"""
    print_test("Log Post Interactions")

    if not TEST_POSTS:
        print_error("No test posts available")
        return False

    interaction_types = ['view', 'like', 'comment', 'share', 'save']
    success_count = 0

    for user_id in TEST_USERS:
        for post_id in TEST_POSTS[:3]:  # Test with first 3 posts
            interaction_type = random.choice(interaction_types)

            payload = {
                "user_id": user_id,
                "post_id": post_id,
                "interaction_type": interaction_type,
                "interaction_metadata": {
                    "source": "test_script",
                    "device": "desktop"
                },
                "dwell_time_seconds": random.uniform(1.0, 10.0)
            }

            try:
                response = requests.post(
                    f"{BASE_URL}/api/v1/posts/interactions",
                    json=payload
                )

                if response.status_code == 201:
                    data = response.json()
                    print_success(
                        f"Logged {interaction_type} for user {user_id[:8]}... "
                        f"on post {post_id[:8]}... (ID: {data['interaction_id']})"
                    )
                    success_count += 1
                else:
                    print_error(
                        f"Failed to log interaction: {response.status_code} - "
                        f"{response.text}"
                    )
            except Exception as e:
                print_error(f"Error logging interaction: {str(e)}")

    print_info(f"Successfully logged {success_count} interactions")
    return success_count > 0


def test_log_interaction_validation():
    """Test validation of post interaction requests"""
    print_test("Interaction Validation")

    # Test invalid interaction type
    payload = {
        "user_id": TEST_USERS[0],
        "post_id": TEST_POSTS[0] if TEST_POSTS else "test_post",
        "interaction_type": "invalid_type"
    }

    response = requests.post(
        f"{BASE_URL}/api/v1/posts/interactions",
        json=payload
    )

    if response.status_code == 400:
        print_success("Correctly rejected invalid interaction type")
    else:
        print_error(f"Should reject invalid interaction type: {response.status_code}")
        return False

    # Test missing required fields
    payload = {
        "user_id": TEST_USERS[0]
        # Missing post_id and interaction_type
    }

    response = requests.post(
        f"{BASE_URL}/api/v1/posts/interactions",
        json=payload
    )

    if response.status_code == 400:
        print_success("Correctly rejected missing required fields")
        return True
    else:
        print_error(f"Should reject missing fields: {response.status_code}")
        return False


def test_get_personalized_feed():
    """Test getting personalized feed"""
    print_test("Get Personalized Feed")

    for user_id in TEST_USERS[:2]:  # Test with first 2 users
        try:
            response = requests.get(
                f"{BASE_URL}/api/v1/posts/feed/{user_id}",
                params={"limit": 10, "offset": 0}
            )

            if response.status_code == 200:
                data = response.json()
                print_success(f"Retrieved feed for user {user_id[:8]}...")
                print_info(f"  Posts returned: {len(data['posts'])}")
                print_info(f"  Total available: {data['total']}")
                print_info(f"  Personalized: {data['metadata']['personalized']}")
                print_info(f"  Strategy: {data['metadata']['recommendation_strategy']}")

                # Show first post details
                if data['posts']:
                    post = data['posts'][0]
                    print_info(f"  First post: '{post['content'][:50]}...'")
                    if 'recommendation_score' in post:
                        print_info(f"  Recommendation score: {post.get('recommendation_score', 'N/A')}")
            else:
                print_error(f"Failed to get feed: {response.status_code} - {response.text}")
                return False

        except Exception as e:
            print_error(f"Error getting feed: {str(e)}")
            return False

    return True


def test_feed_validation():
    """Test feed endpoint validation"""
    print_test("Feed Validation")

    # Test invalid user ID format
    response = requests.get(f"{BASE_URL}/api/v1/posts/feed/invalid_id")

    if response.status_code == 400:
        print_success("Correctly rejected invalid user ID format")
    else:
        print_error(f"Should reject invalid user ID: {response.status_code}")
        return False

    # Test invalid limit parameter
    response = requests.get(
        f"{BASE_URL}/api/v1/posts/feed/{TEST_USERS[0]}",
        params={"limit": "not_a_number"}
    )

    if response.status_code == 400:
        print_success("Correctly rejected invalid limit parameter")
        return True
    else:
        print_error(f"Should reject invalid limit: {response.status_code}")
        return False


def test_trending_posts():
    """Test getting trending posts"""
    print_test("Get Trending Posts")

    timeframes = ['1h', '24h', '7d']

    for timeframe in timeframes:
        try:
            response = requests.get(
                f"{BASE_URL}/api/v1/posts/trending",
                params={"limit": 10, "timeframe": timeframe}
            )

            if response.status_code == 200:
                data = response.json()
                print_success(f"Retrieved trending posts for timeframe: {timeframe}")
                print_info(f"  Posts returned: {len(data['posts'])}")
                print_info(f"  Timeframe hours: {data['metadata']['hours']}")

                if data['posts']:
                    post = data['posts'][0]
                    print_info(
                        f"  Top post: '{post['content'][:50]}...' "
                        f"(score: {post.get('engagement_score', 0):.2f})"
                    )
            else:
                print_error(f"Failed to get trending: {response.status_code} - {response.text}")
                return False

        except Exception as e:
            print_error(f"Error getting trending: {str(e)}")
            return False

    return True


def test_train_post_model():
    """Test training the post recommendation model"""
    print_test("Train Post Recommendation Model")

    # First check if we have enough data
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        cur = conn.cursor()

        cur.execute("SELECT COUNT(*) FROM post_interactions")
        interaction_count = cur.fetchone()[0]

        cur.execute("SELECT COUNT(DISTINCT user_id) FROM post_interactions")
        user_count = cur.fetchone()[0]

        cur.close()
        conn.close()

        print_info(f"Found {interaction_count} interactions from {user_count} users")

        if interaction_count < 10:
            print_warning("Not enough interactions for training (need at least 10)")
            print_warning("Creating more test interactions...")

            # Create more interactions
            for _ in range(20):
                user_id = random.choice(TEST_USERS)
                post_id = random.choice(TEST_POSTS) if TEST_POSTS else None

                if post_id:
                    payload = {
                        "user_id": user_id,
                        "post_id": post_id,
                        "interaction_type": random.choice(['view', 'like', 'comment']),
                        "dwell_time_seconds": random.uniform(1.0, 10.0)
                    }
                    requests.post(f"{BASE_URL}/api/v1/posts/interactions", json=payload)

            print_success("Created additional test interactions")

        if user_count < 2:
            print_warning("Need at least 2 users with interactions for training")
            return False

    except Exception as e:
        print_error(f"Error checking interaction data: {str(e)}")
        return False

    # Train the model
    try:
        print_info("Starting model training (this may take a moment)...")
        response = requests.post(f"{BASE_URL}/api/v1/admin/train-post-model")

        if response.status_code == 200:
            data = response.json()
            print_success(f"Model training completed: {data['message']}")

            if 'metadata' in data:
                metadata = data['metadata']
                print_info(f"  Training samples: {metadata.get('samples', 'N/A')}")
                print_info(f"  User groups: {metadata.get('user_groups', 'N/A')}")
                print_info(f"  Model path: {metadata.get('model_path', 'N/A')}")

            return True
        elif response.status_code == 400:
            data = response.json()
            print_warning(f"Training failed: {data.get('error', 'Unknown error')}")
            print_info(f"  This is expected if there's insufficient data")
            return False
        else:
            print_error(f"Training failed: {response.status_code} - {response.text}")
            return False

    except Exception as e:
        print_error(f"Error training model: {str(e)}")
        return False


def test_feed_after_training():
    """Test that feed uses ML ranking after training"""
    print_test("Verify ML-Powered Feed")

    try:
        response = requests.get(
            f"{BASE_URL}/api/v1/posts/feed/{TEST_USERS[0]}",
            params={"limit": 5}
        )

        if response.status_code == 200:
            data = response.json()

            if data['metadata']['personalized']:
                print_success("Feed is using ML personalization!")
                print_info(f"  Strategy: {data['metadata']['recommendation_strategy']}")

                # Check if posts have recommendation scores
                if data['posts'] and 'recommendation_score' in data['posts'][0]:
                    print_success("Posts have ML recommendation scores")
                    for i, post in enumerate(data['posts'][:3], 1):
                        print_info(
                            f"  Post {i}: score={post['recommendation_score']:.3f}, "
                            f"content='{post['content'][:40]}...'"
                        )
                    return True
                else:
                    print_warning("Posts don't have recommendation scores")
                    return False
            else:
                print_warning("Feed is using fallback ranking (model may not be trained)")
                return False
        else:
            print_error(f"Failed to get feed: {response.status_code}")
            return False

    except Exception as e:
        print_error(f"Error verifying ML feed: {str(e)}")
        return False


def test_database_triggers():
    """Test that database triggers are working"""
    print_test("Database Triggers and Stats")

    try:
        conn = psycopg2.connect(**DB_CONFIG)
        cur = conn.cursor(cursor_factory=RealDictCursor)

        # Check if engagement stats are being updated
        cur.execute("""
            SELECT 
                COUNT(*) as stats_count,
                SUM(view_count) as total_views,
                SUM(like_count) as total_likes
            FROM post_engagement_stats;
        """)

        stats = cur.fetchone()

        if stats and stats['stats_count'] > 0:
            print_success("Post engagement stats are being tracked")
            print_info(f"  Stats entries: {stats['stats_count']}")
            print_info(f"  Total views: {stats['total_views']}")
            print_info(f"  Total likes: {stats['total_likes']}")
            return True
        else:
            print_warning("No engagement stats found (triggers may not be working)")
            print_info("This is normal if no interactions have been logged yet")
            return False

    except Exception as e:
        print_error(f"Error checking triggers: {str(e)}")
        return False
    finally:
        if conn:
            cur.close()
            conn.close()


def run_all_tests():
    """Run all tests and report results"""
    print(f"\n{Colors.HEADER}{Colors.BOLD}{'=' * 70}")
    print(f"  POST RECOMMENDATION SYSTEM - COMPREHENSIVE TEST SUITE")
    print(f"{'=' * 70}{Colors.ENDC}\n")

    print_info(f"Testing API at: {BASE_URL}")
    print_info(f"Database: {DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['dbname']}\n")

    results = {}

    # Setup
    results['setup'] = setup_test_data()

    if not results['setup']:
        print_error("\nTest setup failed. Cannot continue with tests.")
        return

    time.sleep(1)

    # Core tests
    results['health'] = test_health_check()
    time.sleep(0.5)

    results['log_interaction'] = test_log_post_interaction()
    time.sleep(0.5)

    results['interaction_validation'] = test_log_interaction_validation()
    time.sleep(0.5)

    results['personalized_feed'] = test_get_personalized_feed()
    time.sleep(0.5)

    results['feed_validation'] = test_feed_validation()
    time.sleep(0.5)

    results['trending'] = test_trending_posts()
    time.sleep(0.5)

    # results['database_triggers'] = test_database_triggers()
    # time.sleep(0.5)

    # ML tests (may fail if insufficient data)
    # results['train_model'] = test_train_post_model()
    # time.sleep(1)

    if results['train_model']:
        results['ml_feed'] = test_feed_after_training()
    else:
        results['ml_feed'] = None

    # Summary
    print(f"\n{Colors.HEADER}{Colors.BOLD}{'=' * 70}")
    print(f"  TEST SUMMARY")
    print(f"{'=' * 70}{Colors.ENDC}\n")

    passed = sum(1 for v in results.values() if v is True)
    failed = sum(1 for v in results.values() if v is False)
    skipped = sum(1 for v in results.values() if v is None)

    for test_name, result in results.items():
        status = "✓ PASS" if result is True else ("✗ FAIL" if result is False else "⊘ SKIP")
        color = Colors.OKGREEN if result is True else (Colors.FAIL if result is False else Colors.WARNING)
        print(f"{color}{status}{Colors.ENDC} - {test_name.replace('_', ' ').title()}")

    print(f"\n{Colors.BOLD}Results: {passed} passed, {failed} failed, {skipped} skipped{Colors.ENDC}")

    if failed == 0:
        print(f"\n{Colors.OKGREEN}{Colors.BOLD}🎉 All critical tests passed!{Colors.ENDC}")
    else:
        print(f"\n{Colors.WARNING}⚠ Some tests failed. Check logs above for details.{Colors.ENDC}")

    # Recommendations
    print(f"\n{Colors.HEADER}Recommendations:{Colors.ENDC}")

    if not results.get('train_model'):
        print_info("• Generate more interactions to enable ML training (need 100+ interactions from 2+ users)")

    if not results.get('ml_feed'):
        print_info("• Train the model to enable personalized recommendations")

    if not results.get('database_triggers'):
        print_info("• Check if database triggers are installed correctly")

    print()


if __name__ == "__main__":
    run_all_tests()